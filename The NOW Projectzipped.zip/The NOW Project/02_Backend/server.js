const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const amqp = require('amqplib');
const winston = require('winston');
const client = require('prom-client'); // For Prometheus

// 1. SETUP LOGGING (For Logstash)
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        new winston.transports.File({ filename: 'server.log' }), // Logstash reads this
        new winston.transports.Console()
    ]
});

// 2. SETUP APP & SOCKET
const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });

// 3. PROMETHEUS METRICS (Feature: Monitoring)
const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics();
app.get('/metrics', async (req, res) => {
    res.set('Content-Type', client.register.contentType);
    res.end(await client.register.metrics());
});

// 4. RABBITMQ CONNECTION
let channel = null;
async function connectRabbit() {
    try {
        const conn = await amqp.connect('amqp://localhost');
        channel = await conn.createChannel();
        await channel.assertQueue('gps_queue');
        console.log("✅ Connected to RabbitMQ");
    } catch (err) {
        console.error("❌ RabbitMQ connection failed. Is it running?");
    }
}
connectRabbit();

// 5. API ROUTE
app.post('/api/gps', (req, res) => {
    const data = req.body;

    // A. Send to Frontend (Instant Visualization)
    io.emit('gps_update', data);

    // B. Send to Worker (Background Processing)
    if (channel) {
        channel.sendToQueue('gps_queue', Buffer.from(JSON.stringify(data)));
    }

    // C. Log for Logstash
    if (data.speed > 80) {
        logger.warn(`Speed Alert: ${data.driverName} is doing ${data.speed} km/h`);
    } else {
        logger.info(`GPS received for ${data.driverName}`);
    }

    res.sendStatus(200);
});

// 6. START
server.listen(3000, () => console.log("🚀 Backend running on Port 3000"));