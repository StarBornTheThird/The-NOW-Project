const axios = require('axios');

// CONFIGURATION
const API_URL = 'http://localhost:3000/api/gps';

// THE 3 DRIVERS (Features 6, 7, 8: Profiles & Ratings)
// We assign a specific "color" to each for the Frontend to use.
const fleet = [
    { 
        id: "truck_001", 
        name: "Raju (Rash Driver)", 
        color: "red",     // Visualization
        lat: 17.3850, lng: 78.4867, // Charminar
        dest: [17.4500, 78.3800],   // Hi-Tech City
        rating: 3.2,
        weight: 4500,     // Feature 2: Cargo Weight
        fuel: 80,         // Feature 1: Fuel
        fuelBurn: 0.5,    // Burns fuel fast
        speedRange: [60, 110] 
    },
    { 
        id: "truck_002", 
        name: "Rahul (Safe Driver)", 
        color: "green", 
        lat: 17.4000, lng: 78.5500, // Uppal
        dest: [17.2500, 78.4500],   // Airport
        rating: 4.9,
        weight: 1200, 
        fuel: 95, 
        fuelBurn: 0.1,    // Efficient
        speedRange: [40, 60] 
    },
    { 
        id: "truck_003", 
        name: "Priya (Traffic Route)", 
        color: "blue", 
        lat: 17.5000, lng: 78.4000, // Kukatpally
        dest: [17.3500, 78.5500],   // LB Nagar
        rating: 4.5,
        weight: 2100, 
        fuel: 60, 
        fuelBurn: 0.2,
        speedRange: [5, 35]         // Stuck in traffic
    }
];

function moveFleet() {
    fleet.forEach(truck => {
        // 1. SIMULATE MOVEMENT (Linear Interpolation)
        const latDir = (truck.dest[0] - truck.lat) * 0.01;
        const lngDir = (truck.dest[1] - truck.lng) * 0.01;
        
        // Add "Jitter" so it looks real on map
        truck.lat += latDir + (Math.random() - 0.5) * 0.0005;
        truck.lng += lngDir + (Math.random() - 0.5) * 0.0005;

        // 2. SIMULATE SPEED (Feature 3)
        const currentSpeed = Math.floor(Math.random() * (truck.speedRange[1] - truck.speedRange[0]) + truck.speedRange[0]);

        // 3. SIMULATE FUEL (Feature 1)
        truck.fuel = Math.max(0, truck.fuel - truck.fuelBurn);

        // 4. SIMULATE TOLL EVENT (Feature 4)
        // 2% chance per tick to hit a toll
        const event = (Math.random() < 0.02) ? "Toll Gate Paid: ₹150" : null;

        // 5. CALCULATE ETA (Feature 5)
        // Simple logic: Distance remaining * factor
        const distRemaining = Math.abs(truck.dest[0] - truck.lat) + Math.abs(truck.dest[1] - truck.lng);
        const eta = Math.ceil(distRemaining * 1000); 

        // PAYLOAD
        const data = {
            vehicleId: truck.id,
            driverName: truck.name,
            color: truck.color,
            lat: truck.lat,
            lng: truck.lng,
            speed: currentSpeed,
            fuel: truck.fuel.toFixed(1),
            weight: truck.weight,
            rating: truck.rating,
            eta: eta,
            event: event,
            timestamp: new Date()
        };

        // SEND TO BACKEND
        axios.post(API_URL, data)
            .then(() => process.stdout.write(`.`)) // Print dot for heartbeat
            .catch(e => console.log("\n[!] Backend Offline. Start 'server.js' first."));
    });
}

console.log("--- 🚚 FLEET SIMULATOR STARTED (3 TRUCKS) ---");
setInterval(moveFleet, 3000); // Updates every 3 seconds