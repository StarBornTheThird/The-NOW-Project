INSTRUCTIONS:
1. Simply double-click 'index.html' to open it in your browser.
2. OR, if you have VS Code, right-click index.html and select "Open with Live Server".

How to Test the Separation:
Keep your Backend, Worker, and Simulator running (Steps 1-3 from previous guide).

Open login.html in your browser (Double click it).

Test Case 1 (Admin):

Enter admin -> Click Login.

You should see the Map with all 3 trucks moving.

Test Case 2 (Driver):

Open login.html again in a New Tab.

Enter truck_001 -> Click Login.

You should see the Big Speedometer only.

Wait for "Raju" to speed up (randomly happens every few seconds). You will see the screen flash Red and say "⚠️ SLOW DOWN!".

Switch tabs back to Admin; you will see the Admin map is still normal (or showing a tiny alert bubble).

This completes your project with Role-Based Views, all while keeping your existing codebase intact.