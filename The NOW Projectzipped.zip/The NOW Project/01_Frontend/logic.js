// 1. INITIALIZE MAP (Center on Hyderabad)
const map = L.map('map').setView([17.4000, 78.4800], 12);

// Add OpenStreetMap Layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Optional: Add Traffic Layer (If you have a key, insert here. Otherwise works without it)
// L.tileLayer('https://api.tomtom.com/traffic/map/4/tile/flow/relative/{z}/{x}/{y}.png?key=YOUR_KEY').addTo(map);

// 2. CONNECT TO BACKEND
const socket = io('http://localhost:3000');
const vehicles = {}; // Store marker references

socket.on('gps_update', (data) => {
    
    // --- A. MAP VISUALIZATION ---
    if (!vehicles[data.vehicleId]) {
        // CREATE NEW MARKER (Color coded circle)
        const marker = L.circleMarker([data.lat, data.lng], {
            radius: 10,
            fillColor: data.color, // Red, Green, or Blue
            color: '#fff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8
        }).addTo(map).bindPopup(`<b>${data.driverName}</b>`);

        vehicles[data.vehicleId] = { marker: marker, lastPos: [data.lat, data.lng] };
        
        // CREATE SIDEBAR CARD
        createCard(data);
    } else {
        // UPDATE EXISTING MARKER
        const v = vehicles[data.vehicleId];
        v.marker.setLatLng([data.lat, data.lng]);
        
        // DRAW TRAIL (Traffic Visualization)
        // Red trail if slow, Green if fast
        const trailColor = data.speed < 30 ? '#ff4757' : '#2ed573';
        L.polyline([v.lastPos, [data.lat, data.lng]], { color: trailColor, weight: 4 }).addTo(map);
        
        v.lastPos = [data.lat, data.lng];
        
        // UPDATE SIDEBAR CARD
        updateCard(data);
    }
});

// HELPER: Create HTML Card
function createCard(data) {
    const container = document.getElementById('cards-container');
    const div = document.createElement('div');
    div.className = 'card';
    div.id = `card-${data.vehicleId}`;
    div.style.borderLeftColor = data.color; // Match marker color
    
    div.innerHTML = `
        <h3>${data.driverName} <span>⭐ ${data.rating}</span></h3>
        <div class="stat-row">
            <p>🏁 ETA: <span id="eta-${data.vehicleId}">${data.eta}</span> min</p>
            <p>⚖️ ${data.weight} kg</p>
        </div>
        <h1 style="text-align:center; margin: 10px 0;">
            <span id="speed-${data.vehicleId}">0</span> <span style="font-size:12px">km/h</span>
        </h1>
        <label>Fuel Level:</label>
        <progress id="fuel-${data.vehicleId}" value="${data.fuel}" max="100"></progress>
        <div id="alert-${data.vehicleId}" class="alert-text"></div>
    `;
    container.appendChild(div);
}

// HELPER: Update HTML Card
function updateCard(data) {
    document.getElementById(`speed-${data.vehicleId}`).innerText = data.speed;
    document.getElementById(`eta-${data.vehicleId}`).innerText = data.eta;
    
    const fuelBar = document.getElementById(`fuel-${data.vehicleId}`);
    fuelBar.value = data.fuel;
    if(data.fuel < 20) fuelBar.classList.add('low-fuel');

    // Handle Alerts (Speeding or Tolls)
    const alertBox = document.getElementById(`alert-${data.vehicleId}`);
    if (data.event) {
        alertBox.innerText = `🔔 ${data.event}`;
        setTimeout(() => alertBox.innerText = "", 5000); // Clear after 5s
    } else if (data.speed > 80) {
        alertBox.innerText = "⚠️ OVERSPEEDING!";
    } else {
        alertBox.innerText = "";
    }
}