const amqp = require('amqplib');
const mongoose = require('mongoose');

// 1. MONGODB CONNECTION
mongoose.connect('mongodb://127.0.0.1:27017/vehicle_db')
    .then(() => console.log("✅ Connected to MongoDB"))
    .catch(err => console.error("❌ MongoDB connection failed"));

// 2. DEFINE SCHEMA (For Historical Data)
const TripSchema = new mongoose.Schema({
    vehicleId: String,
    driverName: String,
    speed: Number,
    location: { lat: Number, lng: Number },
    alert: String,
    timestamp: Date
});
const TripLog = mongoose.model('TripLog', TripSchema);

// 3. WORKER LOGIC
async function startWorker() {
    try {
        const conn = await amqp.connect('amqp://localhost');
        const channel = await conn.createChannel();
        await channel.assertQueue('gps_queue');
        
        console.log("👷 Worker Active: Waiting for GPS data...");

        channel.consume('gps_queue', async (msg) => {
            if (msg !== null) {
                const data = JSON.parse(msg.content.toString());
                
                // Logic: Only save interesting events or every 10th packet to save space
                // (For demo, we save Alerts)
                let alertMsg = null;
                if (data.speed > 80) alertMsg = "Overspeeding";
                if (data.event) alertMsg = data.event;

                if (alertMsg) {
                    await TripLog.create({
                        vehicleId: data.vehicleId,
                        driverName: data.driverName,
                        speed: data.speed,
                        location: { lat: data.lat, lng: data.lng },
                        alert: alertMsg,
                        timestamp: new Date()
                    });
                    console.log(`[DB SAVE] 💾 Saved Alert for ${data.driverName}: ${alertMsg}`);
                }

                channel.ack(msg);
            }
        });
    } catch (err) {
        console.error("Worker Error:", err);
    }
}

startWorker();