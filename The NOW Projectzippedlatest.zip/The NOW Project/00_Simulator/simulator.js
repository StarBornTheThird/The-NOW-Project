const axios = require("axios")

const API_URL = "http://localhost:3000/api/gps"

const roadNetworks = {
  charminar_to_hitech: [
    [17.385, 78.4867],
    [17.39, 78.495],
    [17.405, 78.505],
    [17.42, 78.51],
    [17.435, 78.515],
    [17.445, 78.39],
    [17.45, 78.38],
  ],
  uppal_to_airport: [
    [17.4, 78.55],
    [17.37, 78.53],
    [17.32, 78.49],
    [17.29, 78.47],
    [17.25, 78.45],
  ],
  kukatpally_to_lbnagar: [
    [17.5, 78.4],
    [17.47, 78.42],
    [17.43, 78.44],
    [17.39, 78.47],
    [17.35, 78.55],
  ],
}

const fleet = [
  {
    id: "truck_001",
    name: "Raju (Rash Driver)",
    color: "red",
    lat: 17.385,
    lng: 78.4867,
    dest: [17.45, 78.38],
    roadPath: roadNetworks.charminar_to_hitech,
    pathIndex: 0,
    rating: 3.2,
    weight: 4500,
    fuel: 85,
    speedRange: [60, 110],
  },
  {
    id: "truck_002",
    name: "Rahul (Safe Driver)",
    color: "green",
    lat: 17.4,
    lng: 78.55,
    dest: [17.25, 78.45],
    roadPath: roadNetworks.uppal_to_airport,
    pathIndex: 0,
    rating: 4.9,
    weight: 1200,
    fuel: 90,
    speedRange: [40, 60],
  },
  {
    id: "truck_003",
    name: "Priya (Traffic Route)",
    color: "blue",
    lat: 17.5,
    lng: 78.4,
    dest: [17.35, 78.55],
    roadPath: roadNetworks.kukatpally_to_lbnagar,
    pathIndex: 0,
    rating: 4.5,
    weight: 2100,
    fuel: 75,
    speedRange: [5, 35],
  },
]

const waypointProgress = {}

function moveFleet() {
  fleet.forEach((truck) => {
    const key = `${truck.id}_${truck.pathIndex}`
    if (!waypointProgress[key]) {
      waypointProgress[key] = 0
    }

    if (truck.pathIndex < truck.roadPath.length - 1) {
      const currentWaypoint = truck.roadPath[truck.pathIndex]
      const nextWaypoint = truck.roadPath[truck.pathIndex + 1]

      waypointProgress[key] += 0.08
      if (waypointProgress[key] > 1) {
        waypointProgress[key] = 1
      }

      truck.lat = currentWaypoint[0] + (nextWaypoint[0] - currentWaypoint[0]) * waypointProgress[key]
      truck.lng = currentWaypoint[1] + (nextWaypoint[1] - currentWaypoint[1]) * waypointProgress[key]

      truck.fuel = Math.max(30, truck.fuel - 0.12)

      if (waypointProgress[key] >= 1) {
        truck.pathIndex++
        delete waypointProgress[key]
      }
    } else {
      truck.pathIndex = 0
      truck.lat = truck.roadPath[0][0]
      truck.lng = truck.roadPath[0][1]
      truck.fuel = Math.min(100, truck.fuel + 50)
      delete waypointProgress[key]
    }

    const currentSpeed = Math.floor(Math.random() * (truck.speedRange[1] - truck.speedRange[0]) + truck.speedRange[0])

    let tollAmount = null
    if (Math.random() < 0.08) {
      tollAmount = 150 + Math.floor(Math.random() * 50)
    }

    const distRemaining = Math.abs(truck.dest[0] - truck.lat) + Math.abs(truck.dest[1] - truck.lng)
    const eta = Math.ceil(distRemaining * 1000)

    const data = {
      vehicleId: truck.id,
      driverName: truck.name,
      color: truck.color,
      lat: truck.lat,
      lng: truck.lng,
      speed: currentSpeed,
      fuel: Math.round(truck.fuel * 10) / 10,
      weight: truck.weight,
      rating: truck.rating,
      eta: eta,
      tollAmount: tollAmount,
      timestamp: new Date(),
    }

    axios
      .post(API_URL, data)
      .then(() => process.stdout.write("."))
      .catch((e) => { })
  })
}

console.log("Fleet simulator started")
setInterval(moveFleet, 3000)
