INSTRUCTIONS:
1. Open terminal in this folder.
2. Run 'npm install'
3. Run 'node simulator.js'
4. KEEP THIS RUNNING. It acts as the vehicles.