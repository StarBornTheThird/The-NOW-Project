const L = window.L
const io = window.io

const map = L.map("map").setView([17.4, 78.48], 12)

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap contributors",
}).addTo(map)

const socket = io("http://localhost:3000")
const vehicles = {}

socket.on("connect", () => {
  console.log("[v0] Connected to backend")
})

socket.on("gps_update", (data) => {
  console.log("[v0] GPS update received for:", data.driverName, "Fuel:", data.fuel, "Alert:", data.alert)
  if (!vehicles[data.vehicleId]) {
    const marker = L.circleMarker([data.lat, data.lng], {
      radius: 10,
      fillColor: data.color,
      color: "#fff",
      weight: 2,
      opacity: 1,
      fillOpacity: 0.8,
    })
      .addTo(map)
      .bindPopup(`<b>${data.driverName}</b>`)

    vehicles[data.vehicleId] = { marker: marker, lastPos: [data.lat, data.lng] }
    createCard(data)
  } else {
    const v = vehicles[data.vehicleId]
    if (v.marker && v.marker.setLatLng) {
      v.marker.setLatLng([data.lat, data.lng])
      console.log("[v0] Marker moved to:", data.lat, data.lng)
    }

    const trailColor = data.speed < 30 ? "#ff4757" : "#2ed573"
    L.polyline([v.lastPos, [data.lat, data.lng]], { color: trailColor, weight: 4 }).addTo(map)

    v.lastPos = [data.lat, data.lng]
    updateCard(data)
  }
})

function createCard(data) {
  console.log("[v0] Creating card for:", data.driverName)
  const container = document.getElementById("cards-container")

  if (!container) {
    console.log("[v0] ERROR: cards-container not found in DOM")
    return
  }

  const div = document.createElement("div")
  div.className = "card"
  div.id = `card-${data.vehicleId}`
  div.style.borderLeftColor = data.color

  div.innerHTML = `
    <h3>${data.driverName} <span>Rating: ${data.rating}</span></h3>
    <div class="stat-row">
      <p>ETA: <span id="eta-${data.vehicleId}">${data.eta}</span> min</p>
      <p>Weight: ${data.weight} kg</p>
    </div>
    <h1 style="text-align:center; margin: 10px 0;">
      <span id="speed-${data.vehicleId}">0</span> <span style="font-size:12px">km/h</span>
    </h1>
    <label>Fuel Level:</label>
    <progress id="fuel-${data.vehicleId}" value="${data.fuel}" max="100"></progress>
    <span id="fuel-text-${data.vehicleId}" style="font-size: 12px;">${data.fuel}%</span>
    <div id="alert-${data.vehicleId}" class="alert-text"></div>
  `
  container.appendChild(div)
  console.log("[v0] Card created and appended for:", data.driverName)
}

function updateCard(data) {
  const speedElem = document.getElementById(`speed-${data.vehicleId}`)
  const etaElem = document.getElementById(`eta-${data.vehicleId}`)
  const fuelBar = document.getElementById(`fuel-${data.vehicleId}`)
  const fuelText = document.getElementById(`fuel-text-${data.vehicleId}`)
  const alertElem = document.getElementById(`alert-${data.vehicleId}`)

  if (speedElem) speedElem.innerText = data.speed
  if (etaElem) etaElem.innerText = data.eta
  if (fuelBar) fuelBar.value = data.fuel
  if (fuelText) fuelText.innerText = data.fuel + "%"

  if (alertElem) {
    if (data.alert) {
      console.log("[v0] Displaying alert for", data.driverName, ":", data.alert)
      alertElem.innerText = data.alert
      alertElem.style.display = "block"
      alertElem.style.color = "#ff4757"
      alertElem.style.fontWeight = "bold"
      alertElem.style.marginTop = "8px"
      alertElem.style.fontSize = "13px"
    } else {
      alertElem.innerText = ""
      alertElem.style.display = "none"
    }
  }

  if (data.fuel < 25) {
    if (fuelBar) fuelBar.style.accentColor = "red"
  } else {
    if (fuelBar) fuelBar.style.accentColor = ""
  }
}

let allLogs = []

async function fetchLogs() {
  try {
    const response = await fetch("http://localhost:3000/api/logs")
    allLogs = await response.json()
    displayLogs(allLogs)
  } catch (err) {
    console.error("Failed to fetch logs:", err)
  }
}

function displayLogs(logs) {
  const container = document.getElementById("logsContainer")
  if (!container) return

  if (!logs || logs.length === 0) {
    container.innerHTML = '<p style="text-align:center; padding: 20px;">No events logged yet</p>'
    return
  }

  container.innerHTML = logs
    .map((log) => {
      const date = new Date(log.timestamp)
      const time = date.toLocaleTimeString()
      const eventType = log.eventType || "UNKNOWN"

      return `
      <div style="padding: 10px; border-bottom: 1px solid #ddd; font-size: 14px;">
        <div style="font-weight: bold;">${log.driverName}</div>
        <div style="color: #666; font-size: 12px;">${time}</div>
        <div style="color: #d32f2f; margin-top: 5px;">${eventType}: ${log.details}</div>
      </div>
    `
    })
    .join("")
}

function filterLogs() {
  const driverVal = (document.getElementById("driverFilter")?.value || "").toLowerCase()
  const eventVal = document.getElementById("eventFilter")?.value || ""

  const filtered = allLogs.filter(
    (log) => log.driverName.toLowerCase().includes(driverVal) && (eventVal === "" || log.eventType === eventVal),
  )

  displayLogs(filtered)
}

const logsBtn = document.getElementById("logsBtn")
const closeBtn = document.getElementById("closeLogsBtn")
const clearBtn = document.getElementById("clearLogsBtn")
const driverFilter = document.getElementById("driverFilter")
const eventFilter = document.getElementById("eventFilter")
const modal = document.getElementById("logsModal")

if (logsBtn) {
  logsBtn.addEventListener("click", () => {
    if (driverFilter) driverFilter.value = ""
    if (eventFilter) eventFilter.value = ""
    if (modal) modal.style.display = "flex"
    fetchLogs()
  })
}

if (closeBtn) closeBtn.addEventListener("click", () => (modal.style.display = "none"))

if (clearBtn) {
  clearBtn.addEventListener("click", async () => {
    if (confirm("Clear all logs?")) {
      await fetch("http://localhost:3000/api/logs/clear", { method: "POST" })
      allLogs = []
      displayLogs([])
    }
  })
}

if (driverFilter) driverFilter.addEventListener("input", filterLogs)
if (eventFilter) eventFilter.addEventListener("change", filterLogs)

window.addEventListener("click", (e) => {
  if (e.target === modal) modal.style.display = "none"
})
