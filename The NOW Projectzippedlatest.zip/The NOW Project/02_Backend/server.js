const express = require("express")
const http = require("http")
const socketIo = require("socket.io")
const cors = require("cors")
const winston = require("winston")

const logger = winston.createLogger({
  level: "info",
  format: winston.format.json(),
  transports: [new winston.transports.File({ filename: "server.log" }), new winston.transports.Console()],
})

const app = express()
app.use(cors())
app.use(express.json())
const server = http.createServer(app)
const io = socketIo(server, { cors: { origin: "*" } })

let eventLog = []
const loggedLowFuelAlert = {}

function logEvent(vehicleId, driverName, eventType, details) {
  const event = {
    timestamp: new Date().toISOString(),
    vehicleId,
    driverName,
    eventType,
    details,
  }
  eventLog.push(event)
  logger.info(JSON.stringify(event))
  console.log("[LOG]", eventType, "-", driverName, "-", details)
}

app.get("/api/logs", (req, res) => {
  res.json(eventLog)
})

app.get("/api/logs/:vehicleId", (req, res) => {
  const driverLogs = eventLog.filter((log) => log.vehicleId === req.params.vehicleId)
  res.json(driverLogs)
})

app.post("/api/logs/clear", (req, res) => {
  eventLog = []
  res.json({ message: "Logs cleared" })
})

app.post("/api/gps", (req, res) => {
  const data = req.body

  let alert = null
  if (data.speed > 80) {
    alert = "OVERSPEEDING"
    logEvent(data.vehicleId, data.driverName, "OVERSPEED", `Speeding at ${data.speed} km/h`)
  }

  if (data.tollAmount) {
    alert = `TOLL: Rs ${data.tollAmount}`
    logEvent(data.vehicleId, data.driverName, "TOLL_GATE", `Toll payment: Rs ${data.tollAmount}`)
  }

  if (data.fuel >= 15 && data.fuel <= 25) {
    if (!loggedLowFuelAlert[data.vehicleId]) {
      alert = "LOW FUEL"
      logEvent(data.vehicleId, data.driverName, "LOW_FUEL", `Fuel level: ${data.fuel}%`)
      loggedLowFuelAlert[data.vehicleId] = true
    }
  } else if (data.fuel > 25) {
    loggedLowFuelAlert[data.vehicleId] = false
  }

  io.emit("gps_update", { ...data, alert })

  res.sendStatus(200)
})

server.listen(3000, () => console.log("Backend running on http://localhost:3000"))
